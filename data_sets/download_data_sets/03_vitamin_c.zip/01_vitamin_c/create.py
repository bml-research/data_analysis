import csv

data = [
    ["Apple", "Fruit", 7],
    ["Banana", "Fruit", 8.7],
    ["Carrot", "Vegetable", 9.3],
    ["Spinach", "Vegetable", 28],
    ["Chicken Breast", "Meat", 0],
    ["Salmon", "Fish", 0],
    ["Almonds", "Nuts", 0],
    ["Oats", "Grains", 0],
    ["Milk", "Dairy", 1],
    ["Cheese", "Dairy", 0],
    ["Broccoli", "Vegetable", 89.2],
    ["Beef", "Meat", 0],
    ["Shrimp", "Fish", 0],
    ["Peanuts", "Nuts", 0],
    ["Rice", "Grains", 0],
    ["Yogurt", "Dairy", 1],
    ["Orange", "Fruit", 53.2],
    ["Potato", "Vegetable", 19.7],
    ["Pork", "Meat", 0],
    ["Tuna", "Fish", 0],
    ["Strawberries", "Fruit", 58.8],
    ["Grapes", "Fruit", 3.6],
    ["Cucumber", "Vegetable", 2.8],
    ["Bell Pepper", "Vegetable", 80.4],
    ["Turkey Breast", "Meat", 0],
    ["Cod", "Fish", 0],
    ["Walnuts", "Nuts", 1.3],
    ["Quinoa", "Grains", 0],
    ["Soy Milk", "Dairy", 1],
    ["Cottage Cheese", "Dairy", 0],
    ["Cauliflower", "Vegetable", 48.2],
    ["Lamb", "Meat", 0],
    ["Crab", "Fish", 0],
    ["Cashews", "Nuts", 0.5],
    ["Barley", "Grains", 0],
    ["Kefir", "Dairy", 2],
    ["Kiwi", "Fruit", 92.7],
    ["Sweet Potato", "Vegetable", 2.4],
    ["Duck", "Meat", 0],
    ["Herring", "Fish", 0],
    ["Blueberries", "Fruit", 9.7],
    ["Asparagus", "Vegetable", 5.6],
    ["Rabbit", "Meat", 0],
    ["Mussels", "Fish", 0],
    ["Hazelnuts", "Nuts", 6.3],
    ["Rye", "Grains", 0],
    ["Buttermilk", "Dairy", 2],
    ["Lemon", "Fruit", 53],
    ["Radish", "Vegetable", 14.8],
    ["Goat Meat", "Meat", 0],
    ["Sardines", "Fish", 0],
    ["Pistachios", "Nuts", 5.6],
    ["Corn", "Grains", 6.8],
    ["Sour Cream", "Dairy", 0.3],
    ["Lime", "Fruit", 29.1],
    ["Celery", "Vegetable", 8],
    ["Venison", "Meat", 0],
    ["Anchovies", "Fish", 0],
    ["Brazil Nuts", "Nuts", 0.7],
    ["Millet", "Grains", 0],
    ["Cream", "Dairy", 0.6],
    ["Grapefruit", "Fruit", 31.2],
    ["Beets", "Vegetable", 4.9],
    ["Buffalo Meat", "Meat", 0],
    ["Trout", "Fish", 0],
    ["Macadamia Nuts", "Nuts", 1.2],
    ["Sorghum", "Grains", 0],
    ["Evaporated Milk", "Dairy", 1],
    ["Mango", "Fruit", 36.4],
    ["Onion", "Vegetable", 7.4],
    ["Goose Meat", "Meat", 0],
    ["Halibut", "Fish", 0],
    ["Chestnuts", "Nuts", 17.8],
    ["Teff", "Grains", 0],
    ["Condensed Milk", "Dairy", 1],
    ["Papaya", "Fruit", 60.9],
    ["Garlic", "Vegetable", 31.2],
    ["Quail Meat", "Meat", 0],
    ["Swordfish", "Fish", 0],
    ["Pine Nuts", "Nuts", 0.8],
    ["Wild Rice", "Grains", 0],
    ["Ice Cream", "Dairy", 0.4],
    ["Cranberries", "Fruit", 13.3],
    ["Green Beans", "Vegetable", 12.2],
    ["Pheasant Meat", "Meat", 0],
    ["Mackerel", "Fish", 0],
    ["Sunflower Seeds", "Nuts", 0],
    ["Buckwheat", "Grains", 0],
    ["Whey Protein", "Dairy", 0],
    ["Pomegranate", "Fruit", 10.2],
    ["Eggplant", "Vegetable", 2.2],
    ["Guinea Fowl", "Meat", 0],
    ["Catfish", "Fish", 0],
    ["Pumpkin Seeds", "Nuts", 0.3],
    ["Amaranth", "Grains", 0],
    ["Ricotta Cheese", "Dairy", 0.2],
    ["Raspberries", "Fruit", 26.2],
    ["Zucchini", "Vegetable", 17.9],
    ["Veal", "Meat", 0],
    ["Tilapia", "Fish", 0],
    ["Blackberries", "Fruit", 21],
    ["Artichoke", "Vegetable", 11.7],
    ["Partridge Meat", "Meat", 0],
    ["Pollock", "Fish", 0],
    ["Watermelon", "Fruit", 8.1],
    ["Brussels Sprouts", "Vegetable", 85],
    ["Squid", "Fish", 0],
    ["Cantaloupe", "Fruit", 36.7],
    ["Kale", "Vegetable", 120],
    ["Octopus", "Fish", 0],
    ["Pear", "Fruit", 4.3],
    ["Leek", "Vegetable", 12],
    ["Clams", "Fish", 0],
    ["Plum", "Fruit", 9.5],
    ["Turnip", "Vegetable", 21],
    ["Oysters", "Fish", 0],
    ["Apricot", "Fruit", 10],
    ["Parsnip", "Vegetable", 17],
    ["Lobster", "Fish", 0],
    ["Peach", "Fruit", 6.6],
    ["Collard Greens", "Vegetable", 35],
    ["Scallops", "Fish", 0],
    ["Cherries", "Fruit", 7],
    ["Fennel", "Vegetable", 12],
    ["Abalone", "Fish", 0],
    ["Avocado", "Fruit", 10],
    ["Bok Choy", "Vegetable", 45],
    ["Sea Bass", "Fish", 0],
    ["Guava", "Fruit", 228],
    ["Endive", "Vegetable", 6.5],
    ["Monkfish", "Fish", 0],
    ["Passion Fruit", "Fruit", 30],
    ["Daikon", "Vegetable", 22],
    ["Snapper", "Fish", 0],
    ["Lychee", "Fruit", 31],
    ["Kohlrabi", "Vegetable", 62],
    ["Grouper", "Fish", 0],
    ["Rambutan", "Fruit", 4.9],
    ["Ginger", "Vegetable", 5],
    ["Haddock", "Fish", 0],
    ["Starfruit", "Fruit", 34.7],
    ["Shallots", "Vegetable", 12],
    ["Pike", "Fish", 0],
    ["Persimmon", "Fruit", 7.5],
    ["Horseradish", "Vegetable", 25],
    ["Sole", "Fish", 0],
    ["Quince", "Fruit", 15]
]

def generate_food_data():
    """
    Generates food data.  Loops through the existing data.

    Returns:
        list: A list of lists representing the food data. The first list is the header,
              and the subsequent lists are the data rows.
    """
    header = ["food catalog number", "food item", "category", "ascorbic acid (mg/100g)"]
    all_data = [header]
    food_catalog_number = 1001
    for item in data:
        food_item, category, ascorbic_acid = item
        all_data.append([food_catalog_number, food_item, category, ascorbic_acid])
        food_catalog_number += 1
    return all_data

def save_food_data_to_csv(food_data, filename="food_data.csv"):
    """
    Saves the food data to a CSV file.

    Args:
        food_data (list): A list of lists representing the food data.
        filename (str, optional): The name of the CSV file to save to.
            Defaults to "food_data.csv".
    """
    with open(filename, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(food_data)
    print(f"Data saved to {filename}")

if __name__ == "__main__":
    food_data = generate_food_data()
    save_food_data_to_csv(food_data)
