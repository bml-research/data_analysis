import pandas as pd
import numpy as np
import random

def generate_b12_dataset(num_rows=250):
    """Generates a dataset with B12 levels based on dietary categories and saves it to a CSV."""

    categories = ['Meat Eater', 'Vegetarian', 'Vegan']
    data = {
        'Sample ID': [f'SAMPLE{i:03d}' for i in range(num_rows)],
        'Category': random.choices(categories, k=num_rows),
        'Serum B12 Concentration (pg/mL)': []
    }

    for category in data['Category']:
        if category == 'Meat Eater':
            # Meat eaters tend to have higher and more consistent B12 levels.
            b12 = np.random.normal(loc=500, scale=150)  # Mean 500, std dev 150
        elif category == 'Vegetarian':
            # Vegetarians may have lower B12, but dairy and eggs can help.
            b12 = np.random.normal(loc=350, scale=180)  # Mean 350, std dev 180
        else:  # Vegan
            # Vegans are at higher risk of deficiency.
            b12 = np.random.normal(loc=250, scale=200)  # Mean 250, std dev 200

        # Ensure non-negative B12 values (realistic)
        b12 = max(0, b12)
        data['Serum B12 Concentration (pg/mL)'].append(round(b12))

    df = pd.DataFrame(data)

    # Save the dataset to a CSV file
    df.to_csv('b12_dataset.csv', index=False)
    print("Dataset saved to b12_dataset.csv")

    return df

# Generate and save the dataset
b12_dataset = generate_b12_dataset()
print(b12_dataset.head())
