import pandas as pd
import numpy as np

# --- Simulation Parameters ---
concentrations = [0, 5, 10, 20, 30, 40, 50, 60]
matrices = {
    "Blood": {"slope": 0.015, "intercept": 0.05},
    "Urine": {"slope": 0.010, "intercept": 0.08},
    "Lymph": {"slope": 0.020, "intercept": 0.03}
}
num_replicates = 3
noise_std_dev = 0.01
min_absorbance = 0.001 # Floor for absorbance values

# --- Generate Data ---
data = []
np.random.seed(42) # for reproducibility

for matrix_name, params in matrices.items():
    slope = params["slope"]
    intercept = params["intercept"]
    for conc in concentrations:
        for rep in range(1, num_replicates + 1):
            # Calculate ideal absorbance
            ideal_absorbance = slope * conc + intercept
            # Add random noise
            noise = np.random.normal(loc=0, scale=noise_std_dev)
            measured_absorbance = ideal_absorbance + noise
            # Ensure absorbance is not below the minimum floor
            measured_absorbance = max(min_absorbance, measured_absorbance)

            data.append({
                "Matrix": matrix_name,
                "Concentration (Units)": conc,
                "Replicate": rep,
                "Absorbance": round(measured_absorbance, 4) # Round for realism
            })

# --- Create DataFrame ---
df_potassium = pd.DataFrame(data)


df_potassium.to_csv("potassium_data.csv", index=False)

# --- Display Data (CSV Format) ---
csv_output = df_potassium.to_csv(index=False)

#print("Simulated Potassium Measurement Dataset (CSV Format):\n")
#print(csv_output)

# Optional: Display as a formatted table (might be truncated if too long)
# print("\nSimulated Potassium Measurement Dataset (Table Format):\n")
# print(df_potassium.to_markdown(index=False))
