import pandas as pd
import random

# Base categories and sugar content
base_data = {
    'Category': ['Apple Pie', 'Cherry Pie', 'Blueberry Pie', 'Pumpkin Pie', 'Pecan Pie', 'Key Lime Pie',
                 'Lemon Meringue Pie', 'Chocolate Cream Pie', 'Banana Cream Pie', 'Coconut Cream Pie',
                 'Strawberry Rhubarb Pie', 'Sweet Potato Pie'],
    'Sugar Content (g/100g)': [15, 22, 18, 14, 28, 19, 20, 25, 16, 21, 17, 13]
}

df_base = pd.DataFrame(base_data)

# Generate 150 unique pie names
pie_names = []
for i in range(150):
    category = random.choice(df_base['Category'].tolist())
    adjectives = ['Delicious', 'Sweet', 'Tart', 'Classic', 'Rich', 'Creamy', 'Spiced', 'Double', 'Rustic', 'Golden', 'Summer', 'Winter', 'Holiday', 'Country']
    fruits = ['Apple', 'Cherry', 'Blueberry', 'Strawberry', 'Rhubarb', 'Lemon', 'Lime', 'Banana', 'Coconut']
    nuts = ['Pecan', 'Walnut', 'Almond']
    creams = ['Cream', 'Meringue', 'Chocolate', 'Custard']
    roots = ['Sweet Potato', 'Pumpkin']

    if 'Apple' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Cinnamon', 'Caramel', 'Baked'])} {random.choice(fruits)} Pie"
    elif 'Cherry' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Sour', 'Sweet', 'Black'])} {random.choice(fruits)} Pie"
    elif 'Blueberry' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Wild', 'Mountain', 'Farm'])} {random.choice(fruits)} Pie"
    elif 'Pumpkin' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Spiced', 'Harvest', 'Maple'])} {random.choice(roots)} Pie"
    elif 'Pecan' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Southern', 'Maple', 'Caramelized'])} {random.choice(nuts)} Pie"
    elif 'Key Lime' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Tropical', 'Florida', 'Zesty'])} {random.choice(fruits)} Pie"
    elif 'Lemon Meringue' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Fluffy', 'Tangy', 'Sunburst'])} {random.choice(creams)} {random.choice(fruits)} Pie"
    elif 'Chocolate Cream' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Dark', 'Milk', 'Fudge'])} {random.choice(creams)} {random.choice(['Chocolate', 'Cocoa'])} Pie"
    elif 'Banana Cream' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Caramelized', 'Classic', 'Silky'])} {random.choice(creams)} {random.choice(fruits)} Pie"
    elif 'Coconut Cream' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Toasted', 'Tropical', 'Flaked'])} {random.choice(creams)} {random.choice(fruits)} Pie"
    elif 'Strawberry Rhubarb' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Sweet', 'Tart', 'Summer'])} {random.choice(['Strawberry', 'Rhubarb', 'Strawberry Rhubarb'])} Pie"
    elif 'Sweet Potato' in category:
        name = f"{random.choice(adjectives)} {random.choice(['Candied', 'Spiced', 'Southern'])} {random.choice(roots)} Pie"

    pie_names.append(name)

# Create the final DataFrame
data = {
    'Pie Name': pie_names,
    'Category': [random.choice(df_base['Category'].tolist()) for _ in range(150)],
    'Sugar Content (g/100g)': [df_base[df_base['Category'] == random.choice(df_base['Category'].tolist())]['Sugar Content (g/100g)'].values[0] for _ in range(150)]
}

df_final = pd.DataFrame(data)

# Save to CSV
df_final.to_csv('pie_data.csv', index=False)

print("pie_data.csv has been created.")
